import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { fromEvent } from 'rxjs'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  board = Array.apply(null, Array(20)).map(_ => Array(20));
  linewidth = 4.3
  layout = new Array(20);
  title = 'ang2';
  cango = true;
  turn = true;

  checkwin(x: number, y: number) {
    let isgreen = -1;
    if (this.board[y][x] == 1) {
      isgreen = 1;
    }
    this.checkdiag(x, y, isgreen);
    this.checkdiag2(x, y, isgreen);
    this.checkvert(x, y, isgreen);
    this.checkhoriz(x, y, isgreen);
  }
  
  checkhoriz(x: number, y: number, isgreen: number) {
    let i = x;
    let cnt = 1;
    while (i > 0 && this.board[y][--i] == isgreen) {
      cnt++;
    }
    while (x < 20-1 && this.board[y][x + 1] == isgreen) {
      cnt++;
      x++;
    }
    if (cnt > 4) {
      Array.apply(0, Array(5)).forEach((_, index) => {
        this.board[y][x - index] = 0;
      });
    }
  }

  checkvert(x: number, y: number, isgreen: number) {
    let i = y;
    let cnt = 1;

    while (i > 0 && this.board[--i][x] == isgreen) {
      cnt++;
    }

    while (y < 20-1 && this.board[y + 1][x] == isgreen) {
      cnt++;
      y++;
    }

    if (cnt > 4) {
      Array.apply(0, Array(5)).forEach((_, index) => {
        this.board[y - index][x] = 0;
      });
    }
  }

  checkdiag(x: number, y: number, isgreen: number) {
    let i = x - 1;
    let j = y - 1;
    let cnt = 1;
    while (i >= 0 && j >= 0 && this.board[j][i] == isgreen && cnt++ && i-- && j--) {
    }

    i = x + 1;
    j = y + 1;
    while (i < 20 && j < 20 && this.board[j][i] == isgreen && cnt++ && i++ && j++) {
    }
    if (cnt == 5) {
      Array.apply(0, Array(5)).forEach((_, index) => {
        this.board[j - 1 - index][i - 1 - index] = 0;
      });
    }
  }

  checkdiag2(x: number, y: number, isgreen: number) {
    let i = x + 1;
    let j = y - 1;
    let cnt = 1;
    while (i <= 20-1 && j >= 0 && this.board[j][i] == isgreen && cnt++ && i++ && j--) {
    }

    i = x - 1;
    j = y + 1;
    while (i >= 0 && j < 20 && this.board[j][i] == isgreen && cnt++ && i-- && j++) {
    }
    if (cnt == 5) {
      Array.apply(0, Array(5)).forEach((_, index) => {
        this.board[j - 1 - index][i + 1 + index] = 0;
      });
    }
  }

  getturn() {
    const sum = this.board.reduce((prevSum, nextSum) => prevSum + nextSum.reduce((prev, next) =>
      prev + (next ? 1 : 0)
      , 0), 0);
    if (sum % 2 == 0) {
      this.turn = true;
    } else {
      this.turn = false;
    }
  }

  constructor(
    private httpClient: HttpClient
  ) {
    setInterval(()=> {
      this.httpClient.get('http://localhost:8080/board').subscribe((board) => {
        board = board as Array<Array<any>>;
         for (let i =0 ; i < 20; i++){
            for (let j =0; j < 20; j++){
              let row = (board as Array<Array<any>>)[i];
              let col = row[j];
              if ( col != undefined ){
                  this.board[i][j] = col;
              }
            }
         }

      });
    }, 2000);
    const clicks = fromEvent(document, 'click');
    clicks.subscribe((ev: Event) => {
      if (!this.cango) {
          return;
      }
      let pe: PointerEvent = ev as (PointerEvent);
      console.log('pe is ' , pe);
      let offset = pe?.view?.pageYOffset;
      let xoffset = pe?.view?.pageXOffset;
      console.log('offset is ', offset);
      let x = xoffset ? xoffset + pe.x : pe.x;
      let y = offset ? offset + pe.y : pe.y;
      let yoffset = offset ?? 0;
      xoffset = xoffset ?? 0;
      let diffx = Math.abs(x+xoffset - Math.round((x+xoffset) / 100) * 100);
      let diffy = Math.abs(y+yoffset-100 - Math.round((y+yoffset-100) / (100 + this.linewidth)) * (100 + this.linewidth));
      let xcoord = Math.round((x+xoffset) / 100);
      let ycoord = Math.round((y-100) / (100 + this.linewidth));
      if (xcoord < 0 || ycoord < 0 || xcoord > 19 || ycoord > 19){
        alert('out of bounds');
        return;
      }
      if (diffx < 44 && diffy < 44) {
        if (this.board[ycoord][xcoord]) {
          return;
        }
        this.getturn();
        this.board[ycoord][xcoord] = this.turn ? 1 : -1;
        this.checkwin(xcoord, ycoord);
        this.httpClient.get(`http://localhost:8080/move/${xcoord}/${ycoord}`).subscribe(board => {
        });
        this.turn = !this.turn;
      }
    });


  }
}
