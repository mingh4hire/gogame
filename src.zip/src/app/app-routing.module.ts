import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CiComponent } from './ci/ci.component';

const routes: Routes = [{path:'ci', component:CiComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
